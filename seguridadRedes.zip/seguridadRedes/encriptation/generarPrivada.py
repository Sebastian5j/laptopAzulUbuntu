from Crypto.PublicKey import RSA
import math 
  

public_key = RSA.importKey(open('publica.pem', 'r').read())
print "e: ",public_key.e
print "n: ",public_key.n

