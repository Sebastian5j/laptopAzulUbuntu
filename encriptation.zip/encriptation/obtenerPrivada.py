import random
import Crypto
from Crypto.PublicKey import RSA
from Crypto import Random

#euclides
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

#euclides extendido
def euclidesExtendido(e, phi):
    d = 0
    x1 = 0
    x2 = 1
    y1 = 1
    temp_phi = phi
    
    while e > 0:
        temp1 = temp_phi/e
        temp2 = temp_phi - temp1 * e
        temp_phi = e
        e = temp2
        
        x = x2- temp1* x1
        y = d - temp1 * y1
        
        x2 = x1
        x1 = x
        d = y1
        y1 = y
    
    if temp_phi == 1:
    	return d + phi


def obtenerPrivada(p, q):
    phi = (p-1) * (q-1)

    #1 < e < phi
    e = random.randrange(1, phi)

    #primos relativos e phi
    g = gcd(e, phi)
    while g != 1:
        e = random.randrange(1, phi)
        g = gcd(e, phi)

    #obtener d con euclides extendido
    d = euclidesExtendido(e, phi)
    
    #private key is (d, n)
    #return (d, n)
    return d

public_key = RSA.importKey( open('publica.pem','r').read() )
n = 275816350077950008213266398347431719213L
e = 65537L
p = 16309749539256011021
q = 16911133393807573153
d2 = obtenerPrivada(p,q)
d = 2236399934058234664674143269137168653232691463L


private_key = RSA.construct((n,  e, d2))
dsmg = private_key.decrypt(msg)
print(dsmg)
print(n)
print(e)
print(d)
print(d2)
